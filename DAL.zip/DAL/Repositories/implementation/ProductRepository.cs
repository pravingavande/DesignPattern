﻿using DAL;
using Repositories.interfaces;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace Repositories.implementation
{
    public class ProductRepository : Repository<ProductMaster>, IProductRepository
    {
         DataBaseContext context { 
            get
            {
                return _db as DataBaseContext;
            } 
        }

        public ProductRepository(DataBaseContext db):base(db)
        {

        }
        public IEnumerable<ProductMaster> GetProductwithCategories()
        {
            var data = (from prd in context.ProductMasters
                       join cat in context.CategoryMasters
                       on prd.CategoryID equals cat.CategoryID
                       select new
                       {
                           prd.ID,
                           prd.ProductName,
                           prd.Desc,
                           prd.UnitPrice,
                           prd.CategoryID,
                           cat.CategroyName
                       }).ToList();
            List <ProductMaster> model= new List<ProductMaster>();
            foreach (var item in data)
            {
                ProductMaster obj = new ProductMaster();
                obj.ID = item.ID;
                obj.ProductName = item.ProductName;
                obj.Desc = item.Desc;
                obj.UnitPrice = item.UnitPrice;
                obj.CategoryID = item.CategoryID;
                obj.CategroyName = item.CategroyName;
                model.Add(obj);
            }
            return model;

        }
    }
}
