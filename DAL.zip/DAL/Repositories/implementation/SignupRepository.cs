﻿using DAL;
using Repositories.interfaces;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Collections;

namespace Repositories.implementation
{
    public class SignupRepository : Repository<SignUp>, ISignUpRepository
    {
        DataBaseContext context { 
        get
          {
                return _db as DataBaseContext;
        
            }
        }
        public SignupRepository(DataBaseContext db):base(db)
        {

        }
        public IEnumerable<SignUp> GetProductListbyID(int ID)
        {
            var data = (from prd in context.SignUps
                        select new 
                        {
                            prd.ID,
                            prd.ProductName
                        }).ToList();
            List<SignUp> model = new List<SignUp>();
            foreach (var item in data)
            {
                SignUp obj = new SignUp();
                obj.ID = item.ID;
                obj.ProductName = item.ProductName;
                model.Add(obj);
            }
            return model;
                   
        }

      
    }
}
