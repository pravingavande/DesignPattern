﻿using DAL;
using Repositories.interfaces;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using Repositories.implementation;

namespace Repositories
{
    public class UnitOfWork : IUnitOfWork
    {
        DataBaseContext _db;
        public UnitOfWork(DataBaseContext db)
        {
            _db = db;

        }
        private IProductRepository _ProductRepo;

        public IProductRepository productrepo
        {
            get 
            { 
                if(_ProductRepo == null)
                _ProductRepo = new ProductRepository(_db);
                return _ProductRepo;
             }
            
        }

        private IRepository<CategoryMaster> _CategoryRepo;
        public IRepository<CategoryMaster> CategoryRepo
        {
            get
            {
                if (_CategoryRepo == null)
                    _CategoryRepo = new Repository<CategoryMaster>(_db);
                return _CategoryRepo;
            }
        }

        private ISignUpRepository _SignUprepo;

        public ISignUpRepository SignUpRepo 
        {
            get
            {
                if (_SignUprepo == null)
                    _SignUprepo = new SignupRepository(_db);
                return _SignUprepo;
            }
         }
        
        public int SaveChanges()
        {
            return _db.SaveChanges();
        }
    }
}
