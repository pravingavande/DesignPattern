﻿using DAL;
using System;
using System.Collections.Generic;
using System.Text;

namespace Repositories.interfaces
{
    interface ISignUpRepository:IRepository<SignUp>
    {
        IEnumerable<SignUp> GetProductListbyID(int ID);
    }
}
