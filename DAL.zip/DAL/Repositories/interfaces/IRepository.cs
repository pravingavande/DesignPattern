﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Repositories.interfaces
{
  public  interface IRepository<TEntity> where  TEntity:class
    {
        void Add(TEntity entity);

        void update(TEntity entity);

        IEnumerable<TEntity> GetAll();

        TEntity Find(Object Id);

        void Delete(object Id);

    }
}
