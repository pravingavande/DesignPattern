﻿using DAL;
using System;
using System.Collections.Generic;
using System.Text;

namespace Repositories.interfaces
{
 public interface IProductRepository:IRepository<ProductMaster>
    {
      IEnumerable <ProductMaster> GetProductwithCategories();

    }
}
