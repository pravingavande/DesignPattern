﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;

namespace DAL
{
    public class DataBaseContext : DbContext
    {
        public DataBaseContext()
        {

        }
        public DataBaseContext(DbContextOptions<DataBaseContext> options):base(options)
        {

        }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseSqlServer("Data Source=LAPTOP-V4EGMGMN;Initial Catalog=EFJune1;User ID=sa;Password=admin@123;");

            }

            base.OnConfiguring(optionsBuilder);
        }

        public DbSet<ProductMaster> ProductMasters{get;set;}

        public DbSet<CategoryMaster> CategoryMasters { get; set; }

        public DbSet<SignUp> SignUps { get; set; }

        
    }
}
