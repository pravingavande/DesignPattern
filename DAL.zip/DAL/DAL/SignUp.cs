﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace DAL
{
   public class SignUp
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int ID { get; set; }

        [Required(ErrorMessage ="Please Enter the User Name")]
        public string UserName { get; set; }
        [Required(ErrorMessage ="Please Enter the Password")]
        public string Password { get; set; }
        [Required(ErrorMessage ="Please Enter a Confirm Password")]
       
        public string ConfirmPassword { get; set; }

        public int MobileNo { get; set; }

        [NotMapped]
        public string Category { get; set; }
        [NotMapped]
        public string Product { get; set; }
        
        [NotMapped]
        public string ProductName { get; set; }

    }
}
