﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DAL;
using Microsoft.AspNetCore.Mvc;
using Repositories;

namespace EF_JUNE__.Controllers
{
    public class CategoryController : Controller
    {
        // DataBaseContext _db;
        IUnitOfWork _uow;
        public CategoryController(IUnitOfWork uow)
        {
            _uow = uow;
        }
        public IActionResult Index()
        {
            //var data = (from p in _db.CategoryMasters
            //            where p.CategoryID > 0
            //            select p
            //          ).ToList();
            var data = _uow.CategoryRepo.GetAll();
            return View(data);
        }

        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Create(CategoryMaster Model)
        {
            ModelState.Remove("CategoryID");
            if (ModelState.IsValid)
            {
                //_db.CategoryMasters.Add(Model);
                //_db.SaveChanges();
                _uow.CategoryRepo.Add(Model);
                _uow.SaveChanges();
                return RedirectToAction("Index");
            }

            return View();
        }

        public IActionResult Edit(int id)
        {
            //CategoryMaster model =_db.CategoryMasters.Find(id);
            CategoryMaster model = _uow.CategoryRepo.Find(id);
            return View("Create", model);

        }
        [HttpPost]
        public IActionResult Edit(CategoryMaster Model)
        {
            if(ModelState.IsValid)
            {
                //_db.CategoryMasters.Update(Model);
                //_db.SaveChanges();
                _uow.CategoryRepo.update(Model);
                _uow.SaveChanges();
                return RedirectToAction("Index");
            }

            return View("Create",Model);
        }

        
    }
}
