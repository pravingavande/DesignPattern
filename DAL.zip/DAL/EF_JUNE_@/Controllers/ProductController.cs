﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DAL;
using Microsoft.AspNetCore.Mvc;
using Repositories;

namespace EF_JUNE__.Controllers
{
    public class ProductController : Controller
    {
        //DataBaseContext _db;

        IUnitOfWork _uow;
        public ProductController(IUnitOfWork uow)
        {
            _uow = uow;
        }
        public IActionResult Index()
        {

            //IEnumerable<ProductMaster>  data = (from p in _db.ProductMasters join
            //             q in _db.CategoryMasters
            //            on p.CategoryID equals q.CategoryID
            //            select new ProductMaster
            //            {
            //                ID=p.ID,
            //                ProductName=p.ProductName,
            //                Desc=p.Desc,
            //                UnitPrice=p.UnitPrice,
            //                CategoryID=p.CategoryID,
            //                CategroyName=q.CategroyName

            //            }

            //            ).ToList();
            //var data = _uow.productrepo.GetAll();
            var data = _uow.productrepo.GetProductwithCategories();
            return View(data);
        }

        public IActionResult Create()
        {
            // ViewData["CategoryList"] = _db.CategoryMasters.ToList();
            ViewData["CategoryList"] = _uow.CategoryRepo.GetAll();

            return View();
        }

        [HttpPost]
        public IActionResult Create(ProductMaster model)
        {
            ModelState.Remove("ID");
            if(ModelState.IsValid)
            {
                // _db.ProductMasters.Add(model);
                _uow.productrepo.Add(model);
                _uow.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewData["CategoryList"] = _uow.CategoryRepo.GetAll();
            return View();
        }

        public IActionResult Edit(int ID)
        {

            //ViewData["CategoryList"] = _db.CategoryMasters.ToList();
            //ProductMaster model = _db.ProductMasters.Find(ID);
            ViewData["CategoryList"] = _uow.CategoryRepo.GetAll();
            ProductMaster model = _uow.productrepo.Find(ID);

            return View("Create",model);
        }

        [HttpPost]
        public IActionResult Edit(ProductMaster Model)
        {
            ModelState.Remove("ID");
            if(ModelState.IsValid)
            {
                //_db.ProductMasters.Update(Model);
                //_db.SaveChanges();
                _uow.productrepo.update(Model);
                _uow.SaveChanges();

                return RedirectToAction("Index");
            }
            ViewData["CategoryList"]=_uow.CategoryRepo.GetAll();
            return View("Create",Model);
        }

        public IActionResult Delete(int ID)
        {
            //ProductMaster model = _db.ProductMasters.Find(ID);
            
                //_db.ProductMasters.Remove(model);
                //_db.SaveChanges();
                _uow.productrepo.Delete(ID);
                _uow.SaveChanges();
                return RedirectToAction("Index");

           
           // return View();
           
        }
    }
}
