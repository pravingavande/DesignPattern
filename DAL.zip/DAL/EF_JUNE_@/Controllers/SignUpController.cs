﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DAL;
using Microsoft.AspNetCore.Mvc;
using Repositories;

namespace EF_JUNE__.Controllers
{
    public class SignUpController : Controller
    {
        IUnitOfWork _uow;

        public SignUpController(IUnitOfWork uow)
        {
            _uow = uow;
        }
        public IActionResult SignUp()
        {
            var data = _uow.SignUpRepo.GetAll();
            ViewBag.CategoryList = data;
            return View();
        }

      
      



    }
}
